/* Routing + sheet behavior. Availability and booking belong to the embedded provider.
 * Home is a permanent backdrop (never hidden). Booking/Work/each Service are
 * `.sheet` elements that overlay Home; every route's hash equals a real element
 * id, so plain anchor navigation (and the no-JS fallback) works without any JS.
 */
(() => {
  'use strict';

  const home = document.getElementById('home');
  const sheets = new Map([...document.querySelectorAll('main .sheet[id]')].map((el) => [el.id, el]));
  const backdrop = document.getElementById('sheet-backdrop');
  const scrollPositions = new Map();
  const HOME_TITLE = document.title;
  const bookingNotice = document.getElementById('booking-notice');

  let activeRoute = null;
  let openSheet = null;
  let pendingFrame = null;
  // The policy announcement shows the first time Booking opens on each visit.
  let bookingNoticeSeen = false;

  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';

  function routeFromLocation() {
    const raw = location.hash.slice(1) || 'home';
    if (raw === 'home' || sheets.has(raw)) return raw;
    history.replaceState(null, '', '#home');
    return 'home';
  }

  function ensureScheduler() {
    const container = document.getElementById('scheduler-container');
    if (container.childElementCount) return;
    const template = document.getElementById('scheduler-template');
    container.append(template.content.cloneNode(true));
  }

  const bookingNoticeOpen = () => bookingNotice && !bookingNotice.hidden;

  function dismissBookingNotice() {
    bookingNoticeSeen = true;
    bookingNotice.hidden = true;
    document.getElementById('booking-title').focus({ preventScroll: true });
  }

  // Revealing/dismissing a sheet is split from the `hidden` attribute's own
  // display:none, because toggling `hidden` and the open transform in the same
  // tick gives the browser nothing to transition from — it just pops. Instead:
  // un-hide, force a reflow so that closed frame actually gets painted, then on
  // the next frame flip the class that drives the animated transform/opacity.
  // Closing reverses that: start the animation immediately, only finalize
  // `hidden = true` once it's actually finished (or a fallback timer fires, in
  // case a transitionend is missed — e.g. reduced-motion strips the transition).
  const SHEET_TRANSITION_MS = 280;

  // revealSheet's class-add and dismissSheet's hidden-finalize are both
  // deferred (one animation frame; one transition/timeout). A fast reopen or
  // reclose before either fires must cancel it — otherwise the stale callback
  // still runs later and undoes whatever navigation happened in the meantime.
  function cancelPendingSheetAnimation(sheet) {
    if (sheet.__revealFrame) {
      cancelAnimationFrame(sheet.__revealFrame);
      sheet.__revealFrame = null;
    }
    if (sheet.__dismissTimeout) {
      clearTimeout(sheet.__dismissTimeout);
      sheet.__dismissTimeout = null;
    }
    if (sheet.__dismissListener) {
      sheet.removeEventListener('transitionend', sheet.__dismissListener);
      sheet.__dismissListener = null;
    }
  }

  function revealSheet(sheet) {
    cancelPendingSheetAnimation(sheet);
    sheet.hidden = false;
    backdrop.hidden = false;
    void sheet.offsetHeight; // eslint-disable-line no-unused-expressions -- force the reflow described above
    sheet.__revealFrame = requestAnimationFrame(() => {
      sheet.__revealFrame = null;
      sheet.classList.add('sheet-shown');
      backdrop.classList.add('sheet-shown');
    });
  }

  function dismissSheet(sheet) {
    cancelPendingSheetAnimation(sheet);
    sheet.classList.remove('sheet-shown');
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      sheet.hidden = true;
      // Only display:none the shared backdrop if nothing re-opened it since
      // (e.g. tapping straight from one sheet into another re-shows it first).
      if (!backdrop.classList.contains('sheet-shown')) backdrop.hidden = true;
    };
    sheet.__dismissListener = (event) => {
      if (event.target !== sheet || event.propertyName !== 'transform') return;
      finish();
    };
    sheet.addEventListener('transitionend', sheet.__dismissListener);
    sheet.__dismissTimeout = setTimeout(finish, SHEET_TRANSITION_MS + 80);
  }

  function closeActiveSheet() {
    if (openSheet) {
      const sheet = openSheet;
      openSheet = null;
      backdrop.classList.remove('sheet-shown');
      dismissSheet(sheet);
    }
    document.body.classList.remove('sheet-open');
  }

  function showRoute(route, moveFocus = true) {
    if (route === activeRoute) return;
    // An unsettled route still has the previous route's window offset.
    if (activeRoute === 'home' && pendingFrame === null) {
      scrollPositions.set('home', window.scrollY);
    }
    if (pendingFrame !== null) {
      cancelAnimationFrame(pendingFrame);
      pendingFrame = null;
    }

    if (route === 'home') {
      closeActiveSheet();
      activeRoute = 'home';
      document.title = HOME_TITLE;
      pendingFrame = requestAnimationFrame(() => {
        if (moveFocus) home.querySelector('h1').focus({ preventScroll: true });
        window.scrollTo(0, scrollPositions.get('home') || 0);
        pendingFrame = null;
      });
      return;
    }

    const sheet = sheets.get(route);
    if (!sheet) return;
    // Going straight from one sheet to another (e.g. Work → a service): the old
    // one animates out on its own, while the new one animates in below — the
    // shared backdrop just stays put, since dismissSheet checks for that.
    if (openSheet && openSheet !== sheet) dismissSheet(openSheet);
    openSheet = sheet;
    document.body.classList.add('sheet-open');
    activeRoute = route;
    if (route === 'booking') {
      ensureScheduler();
      if (bookingNotice && !bookingNoticeSeen) bookingNotice.hidden = false;
    }
    const heading = sheet.querySelector('h1, h2');
    document.title = heading ? `Kali Elisander | ${heading.textContent.trim()}` : HOME_TITLE;
    revealSheet(sheet);

    // Focus and scroll together after layout. Never recreate the iframe on return.
    pendingFrame = requestAnimationFrame(() => {
      sheet.scrollTop = 0;
      const focusTarget =
        route === 'booking' && bookingNoticeOpen() ? document.getElementById('booking-notice-title') : heading;
      if (moveFocus && focusTarget) focusTarget.focus({ preventScroll: true });
      pendingFrame = null;
    });
  }

  function navigate(route) {
    if (route === activeRoute) return;
    history.pushState(null, '', `#${route}`);
    showRoute(route);
  }

  document.addEventListener('click', (event) => {
    if (
      event.defaultPrevented ||
      event.button !== 0 ||
      event.metaKey ||
      event.ctrlKey ||
      event.shiftKey ||
      event.altKey
    )
      return;

    if (event.target.closest('.skip-link')) {
      event.preventDefault();
      if (pendingFrame !== null) cancelAnimationFrame(pendingFrame);
      pendingFrame = null;
      const main = document.getElementById('main-content');
      main.focus({ preventScroll: true });
      window.scrollTo(0, main.offsetTop);
      return;
    }
    if (event.target.closest('[data-dismiss-notice]')) {
      event.preventDefault();
      dismissBookingNotice();
      return;
    }
    if (event.target.closest('[data-close-sheet]')) {
      event.preventDefault();
      navigate('home');
      return;
    }
    if (event.target === backdrop) {
      navigate('home');
      return;
    }
    const link = event.target.closest('a[href^="#"]');
    if (!link) return;
    const route = link.getAttribute('href').slice(1) || 'home';
    if (route !== 'home' && !sheets.has(route)) return;

    event.preventDefault();
    navigate(route);
  });

  document.addEventListener('keydown', (event) => {
    if (!document.body.classList.contains('sheet-open') || !openSheet) return;
    // The announcement sits on top of the Booking sheet: Escape and Tab act on it first.
    const noticeOnTop = openSheet.id === 'booking' && bookingNoticeOpen();
    if (event.key === 'Escape') {
      if (noticeOnTop) dismissBookingNotice();
      else navigate('home');
      return;
    }
    if (event.key !== 'Tab') return;
    const focusable = (noticeOnTop ? bookingNotice : openSheet).querySelectorAll(
      'a[href], button:not([disabled]), iframe, [tabindex]:not([tabindex="-1"])',
    );
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  // hashchange also handles links opened directly and manually edited addresses.
  window.addEventListener('popstate', () => showRoute(routeFromLocation()));
  window.addEventListener('hashchange', () => showRoute(routeFromLocation()));

  // The drag gesture below animates through the same `--sheet-progress`
  // variable the click-driven open/close uses (0 closed → 1 open), set as an
  // inline style during the drag itself so it overrides the class-based value
  // — and with the CSS transition switched off while dragging, so the sheet
  // tracks the finger 1:1 instead of laggily easing toward each new position.
  // Booking only opens by tapping; there is no drag-to-open.
  const DRAG_DISTANCE = 220;

  // Swipe-down-to-close on each sheet's drag handle only, so it never fights
  // scrolling or tapping inside the sheet's own content (iframe included).
  if (window.PointerEvent) {
    for (const sheet of sheets.values()) {
      const handle = sheet.querySelector('.sheet-handle');
      if (!handle) continue;
      let startY = null;
      let progress = 1;
      let dragging = false;
      handle.addEventListener('pointerdown', (event) => {
        event.preventDefault(); // no native text-selection/drag-image while dragging the handle
        dragging = true;
        startY = event.clientY;
        sheet.style.transition = 'none';
        backdrop.style.transition = 'none';
        handle.setPointerCapture(event.pointerId);
      });
      handle.addEventListener('pointermove', (event) => {
        if (!dragging) return;
        const draggedDown = Math.max(0, event.clientY - startY);
        progress = Math.max(0, 1 - draggedDown / DRAG_DISTANCE);
        sheet.style.setProperty('--sheet-progress', progress);
        backdrop.style.opacity = String(progress);
      });
      const endDrag = () => {
        if (!dragging) return;
        dragging = false;
        sheet.style.transition = '';
        backdrop.style.transition = '';
        sheet.style.removeProperty('--sheet-progress');
        backdrop.style.opacity = '';
        if (progress < 0.65) navigate('home');
        progress = 1;
      };
      handle.addEventListener('pointerup', endDrag);
      handle.addEventListener('pointercancel', endDrag);
    }
  }

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').catch(() => {
        /* Offline shell is a nice-to-have; a failed registration must not break the site. */
      });
    });
  }

  // Reviews fade/slide in as they're scrolled into view instead of popping in.
  // The base CSS starts every `.testimonial` at opacity:0, so a browser with
  // no IntersectionObserver support must reveal them immediately here — a
  // review must never end up permanently invisible (no-JS gets the same
  // guarantee, via the noscript stylesheet, since this script never runs then).
  const testimonials = [...document.querySelectorAll('.testimonial')];
  if ('IntersectionObserver' in window) {
    // Home's own review sits close enough to the fold that it can already be
    // intersecting the instant the observer attaches — with no delay, that
    // reveal fires within the same frame as page load and never reads as an
    // animation at all. A minimum delay (plus a light stagger, in case more
    // than one is ever in view at once) guarantees a visible pause-then-fade
    // everywhere, not just for reviews a visitor actually has to scroll to.
    const BASE_DELAY_MS = 350;
    const STAGGER_MS = 120;
    let revealCount = 0;
    const revealObserver = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          revealObserver.unobserve(entry.target);
          const delay = BASE_DELAY_MS + Math.min(revealCount++, 3) * STAGGER_MS;
          setTimeout(() => entry.target.classList.add('is-visible'), delay);
        }
      },
      { threshold: 0.3 },
    );
    testimonials.forEach((el) => revealObserver.observe(el));
  } else {
    testimonials.forEach((el) => el.classList.add('is-visible'));
  }

  const initialRoute = routeFromLocation();
  showRoute(initialRoute, initialRoute !== 'home');
})();
