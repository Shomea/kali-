/* Minimal app-shell cache. Never touches the cross-origin booking iframe or any
 * other third-party request — only same-origin app-shell assets are cached.
 *
 * Network-first, not cache-first: this site ships changes often, and a
 * cache-first strategy means anyone who visited before a deploy stays stuck
 * on the old shell indefinitely — the service worker itself, not Vercel,
 * would keep serving stale HTML/CSS/JS forever. Network-first always prefers
 * the live deploy when online, and only falls back to the cache when offline.
 * Bump CACHE_NAME on any shape change to SHELL_ASSETS itself (adding/removing
 * a precached file) so the old cache gets cleaned up — it's no longer needed
 * just to bust content changes, since network-first already picks those up. */
'use strict';

const CACHE_NAME = 'kaliklipz-shell-v2';
const SHELL_ASSETS = [
  '/',
  'index.html',
  'styles.css',
  'app.js',
  'manifest.json',
  'assets/favicon.svg',
  'assets/logo.png',
  'assets/hero-660.webp',
  'assets/hero-1320.webp',
  'assets/client-1.jpeg',
  'assets/client-2.jpeg',
  'assets/client-3.jpeg',
  'assets/icons/icon-76.png',
  'assets/icons/icon-120.png',
  'assets/icons/icon-180.png',
  'assets/icons/icon-192.png',
  'assets/icons/icon-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(SHELL_ASSETS))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((names) => Promise.all(names.filter((name) => name !== CACHE_NAME).map((name) => caches.delete(name))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  // Cross-origin requests (the FullCap scheduler, Google Fonts, Maps, Instagram)
  // are never intercepted — the provider and third parties own their own responses.
  if (url.origin !== self.location.origin) return;
  if (event.request.method !== 'GET') return;

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        }
        return response;
      })
      .catch(() => caches.match(event.request)),
  );
});
