# Kali Elisander

A static, installable website for Kali Elisander at Headlines in Tampa. No framework, build step, or
packages are required.

## Hosting

Upload everything in this folder to any static HTTPS host (Netlify, Vercel, Cloudflare Pages, GitHub
Pages, or similar), keeping the same folder structure. No server configuration or route rewrites are
needed. HTTPS is required for the "Add to Home Screen" install feature to work.

## Preview locally

From this folder:

```sh
python3 -m http.server 8080
```

Then open `http://localhost:8080`.

## Files

- `index.html` — all page content, including every service's price, duration, and description
- `styles.css` — colors, fonts, and layout
- `app.js` — page navigation and panel behavior
- `manifest.json`, `sw.js` — home-screen install and offline support
- `assets/` — photos, logo, and app icons

Booking is handled by the embedded FullCap scheduler; the site never collects appointment details itself.
